class MazeGenerator:
    pass
